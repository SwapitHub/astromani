// const express = require("express");
// const {
//   getAddServices,
//   deleteAddServices,
//   postAddServices,
// } = require("../controllers/adminSpiritualServicesControllers");
// const adminServicesRoute = express.Router();

// adminServicesRoute.get("/get-add-AdminServices-astrologer", getAddServices);

// adminServicesRoute.delete(
//   "/delete-AdminServices-astrologer/:id",
//   deleteAddServices
// );

// adminServicesRoute.post("/post-add-AdminServices-astrologer", postAddServices);

// module.exports = adminServicesRoute;
