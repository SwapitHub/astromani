require("dotenv").config();
const express = require("express");
const Razorpay = require("razorpay");
const cors = require("cors");
const crypto = require("crypto");
const mongoose = require("mongoose");
const UserLogin = require("../models/userLoginModel");
const UserPayment = require("../models/razorpayModel");

const razorpayRouter = express.Router();
razorpayRouter.use(cors());
razorpayRouter.use(express.json());
// Razorpay instance
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

const getRazorpayPayment = async (req, res) => {
  try {
    const query = req.params.query; // FIXED

    // Pagination
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    if (!query) {
      return res.status(400).json({ error: "Query parameter is required" });
    }

    let searchCondition = { userMobile: query };

    // If query is an ObjectId, search by _id instead
    if (mongoose.Types.ObjectId.isValid(query)) {
      searchCondition = { _id: new mongoose.Types.ObjectId(query) };
    }

    // Count total documents
    const totalCount = await UserPayment.countDocuments(searchCondition);

    const loginUsers = await UserPayment.find(searchCondition)
      .skip(skip)
      .limit(limit)
      .sort({ createdAt: -1 }); // newest first

    if (!loginUsers.length) {
      return res.status(404).json({ error: "No login details found" });
    }

    const totalPages = Math.ceil(totalCount / limit);

    res.json({
      data: loginUsers,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        nextPage: page < totalPages ? page + 1 : null,
        prevPage: page > 1 ? page - 1 : null,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch user login details" });
  }
};


const getRazorpayList = async (req, res) => {
  try {
    const userMobile = req.params.userMobile;

    const result = await UserPayment.aggregate([
      { $match: { userMobile: userMobile } },

      {
        $group: {
          _id: "$userMobile",
          totalAmount: { $sum: "$amount" },
          orders: { $push: "$$ROOT" },
        },
      },

      {
        $project: {
          _id: 0,
          userMobile: "$_id",
          totalAmount: 1,
          orders: 1,
        },
      },
    ]);

    if (result.length === 0) {
      return res.status(404).json({ message: "No orders found for this user" });
    }

    res.json(result[0]);
  } catch (err) {
    console.error("Error fetching user order list:", err); // Log the error
    res.status(500).json({
      message: err.message || "Failed to fetch create-order-user-list",
    });
  }
};

const postRazorpayOrder = async (req, res) => {
  try {
    const { amount, currency, userMobile, extraAmount, totalAmount } = req.body;

    // Validate input
    if (!amount || !currency || !userMobile) {
      return res
        .status(400)
        .json({ error: "Amount, currency, and userMobile are required" });
    }

    // Create Razorpay order
    const options = {
      amount: amount * 100, // Convert to paise
      currency: currency,
      receipt: `receipt_${Date.now()}`,
      payment_capture: 1,
    };

    const order = await razorpay.orders.create(options);

    // Create temporary payment record with "created" status
    const newPayment = new UserPayment({
      order_id: order.id,
      amount: amount,
      extraAmount: extraAmount || 0,
      totalAmount: totalAmount || 0,
      userMobile: userMobile,
      currency: currency,
      status: "FAILED", // Initial state
      createdAt: new Date(),
    });

    await newPayment.save();

    res.json(order);
  } catch (error) {
    console.error("Error in /create-order:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const getAllUsersWithPaymentHistory = async (req, res) => {
  try {
    let page = Number(req.query.page) || 1;
    let limit = Number(req.query.limit) || 10;
    let search = req.query.search || "";

    let skip = (page - 1) * limit;

    // SEARCH FILTER
    let searchFilter = {};
    if (search) {
      const searchNum = Number(search);
      searchFilter = {
        $or: [
          { name: { $regex: search, $options: "i" } },
          ...(isNaN(searchNum) ? [] : [{ phone: searchNum }]),
        ],
      };
    }

    // Count total matched users
    const totalUsers = await UserLogin.countDocuments(searchFilter);

    const users = await UserLogin.aggregate([
      { $match: searchFilter },

      {
        $lookup: {
          from: "payments",
          localField: "phone",
          foreignField: "userMobile",
          as: "paymentHistory",
        },
      },

      { $sort: { createdAt: -1 } },
      { $skip: skip },
      { $limit: limit },
    ]);

    const totalPages = Math.ceil(totalUsers / limit);

    return res.json({
      success: true,
      page,
      limit,
      search,
      totalUsers,
      totalPages,
      hasNextPage: page < totalPages,
      hasPrevPage: page > 1,
      nextPage: page < totalPages ? page + 1 : null,
      prevPage: page > 1 ? page - 1 : null,
      data: users,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

const postRazorpayVeryFy = async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } =
      req.body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    if (!process.env.RAZORPAY_KEY_SECRET) {
      console.error("Razorpay key secret is not configured");
      return res.status(500).json({ error: "Server configuration error" });
    }

    const body = razorpay_order_id + "|" + razorpay_payment_id;
    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(body)
      .digest("hex");

    const isSignatureValid = expectedSignature === razorpay_signature;

    if (!isSignatureValid) {
      await UserPayment.findOneAndUpdate(
        { order_id: razorpay_order_id },
        { status: "failed", error: "Invalid signature" }
      );

      return res
        .status(400)
        .json({ success: false, message: "Invalid payment signature" });
    }

    // Signature is valid - update payment status
    const updatedPayment = await UserPayment.findOneAndUpdate(
      { order_id: razorpay_order_id },
      {
        payment_id: razorpay_payment_id,
        signature: razorpay_signature,
        status: "PASSED",
        paidAt: new Date(),
      },
      { new: true }
    );

    if (!updatedPayment) {
      return res.status(404).json({ error: "Order not found" });
    }

    // Update user's total amount only after successful payment
    const user = await UserLogin.findOneAndUpdate(
      { phone: updatedPayment.userMobile },
      { $inc: { totalAmount: updatedPayment.totalAmount } },
      { new: true }
    );

    if (!user) {
      console.error("User not found for payment:", updatedPayment);
    }

    return res.json({
      success: true,
      message: "Payment verified and saved to DB",
    });
  } catch (error) {
    console.error("Error in /verify-payment:", error);

    // Additional error logging for crypto errors
    if (error.message.includes("ERR_INVALID_ARG_TYPE")) {
      console.error(
        "Crypto key error - verify RAZORPAY_KEY_SECRET is set in environment"
      );
    }

    return res.status(500).json({ error: "Internal server error" });
  }
};

const postRazorpayCancelOrder = async (req, res) => {
  try {
    const { order_id, error } = req.body;

    if (!order_id) {
      return res.status(400).json({ error: "Order ID is required" });
    }

    // Update the payment record with failed status
    await UserPayment.findOneAndUpdate(
      { order_id: order_id },
      {
        status: "failed",
        error: error?.description || "Payment failed",
      }
    );

    res.json({ success: true, message: "Order marked as failed" });
  } catch (error) {
    console.error("Error in /cancel-order:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

module.exports = {
  getRazorpayPayment,
  getRazorpayList,
  postRazorpayOrder,
  postRazorpayVeryFy,
  postRazorpayCancelOrder,
  getAllUsersWithPaymentHistory,
};
