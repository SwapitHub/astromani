const mongoose = require("mongoose");

const transactionAdminAstroSchema = new mongoose.Schema({
  paymentDate: { type: String },
  email: { type: String, required: true },
  Amount: { type: Number, required: true },
  Payment_Method: { type: String, required: true },
  Transaction_id: { type: String, required: true },
  astrologerName: { type: String, required: true },
  astrologer_id: String,
  remaining_amount: String,
});

const transactionAdminAstr = mongoose.model(
  "transactionAdminAstr",
  transactionAdminAstroSchema
);

module.exports = transactionAdminAstr;
